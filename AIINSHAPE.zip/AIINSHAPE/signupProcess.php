<?php
require 'vendor/autoload.php'; // Include MongoDB library via Composer

use MongoDB\Client;

header('Content-Type: text/html; charset=utf-8');

try {
    // Connect to MongoDB
    $mongoClient = new Client("mongodb+srv://@cluster0.v70wf.mongodb.net/?retryWrites=true&w=majority");

    // Select the database and collection
    $database = $mongoClient->selectDatabase('AI');
    $collection = $database->selectCollection('USER');
} catch (Exception $e) {
    die("Failed to connect to MongoDB: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirmPassword = trim($_POST['confirm_password'] ?? '');
    $height = (float)($_POST['height'] ?? 0);
    $weight = (float)($_POST['weight'] ?? 0);
    $age = (int)($_POST['age'] ?? 0);
    $fitnessGoal = trim($_POST['fitness_goal'] ?? '');
    $experienceLevel = trim($_POST['experience_level'] ?? '');

    // Validate data
    $errors = [];
    if (empty($name) || empty($email) || empty($password) || empty($confirmPassword)) {
        $errors[] = "All fields are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    if ($age <= 0 || $height <= 0 || $weight <= 0) {
        $errors[] = "Age, height, and weight must be positive numbers.";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
        exit;
    }

    // Check if email already exists
    try {
        $existingUser = $collection->findOne(['email' => $email]);
        if ($existingUser) {
            echo "<p>Email is already registered.</p>";
            exit;
        }
    } catch (Exception $e) {
        die("Error checking existing user: " . $e->getMessage());
    }

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare user data
    $userData = [
        'name' => $name,
        'email' => $email,
        'password' => $hashedPassword,
        'height' => $height,
        'weight' => $weight,
        'age' => $age,
        'fitness_goal' => $fitnessGoal,
        'experience_level' => $experienceLevel,
        'chat_history' => [], // Initialize chat history as an empty array
        'created_at' => new MongoDB\BSON\UTCDateTime((new DateTime())->getTimestamp() * 1000), // Store in MongoDB format
    ];

    // Insert user data into MongoDB
    try {
        $result = $collection->insertOne($userData);

        if ($result->getInsertedCount() === 1) {
            echo "<p>Signup successful! Redirecting to login...</p>";
            header('Refresh: 3; URL=signin.php'); // Redirect after 3 seconds
            exit;
        } else {
            echo "<p>Failed to register. Please try again.</p>";
        }
    } catch (Exception $e) {
        die("Error saving user: " . $e->getMessage());
    }
} else {
    echo "<p>Invalid request method.</p>";
}
?>
