<?php
$api_url = "https://0c34-35-196-185-41.ngrok-free.app/recommend"; // Replace with your Ngrok URL

$data = array(
    "query" => "i want to cut what should i do?",
    "api_key" => "",//gemini api
);

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

$response = curl_exec($ch);
curl_close($ch);

if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
    exit;
} 

// Decode the JSON response
$response_data = json_decode($response, true);

// Extract the 'response' key from the API response
$answer = isset($response_data['response']) ? $response_data['response'] : "No response received.";

// Split the response into lines and display
$lines = explode("\n", $answer); // Split the response into lines

echo "<div style='font-family: Arial, sans-serif; line-height: 1.6;'>";
echo "<h2>Recommended Triceps Exercises</h2>";
echo "<ul>";

foreach ($lines as $line) {
    if (!empty(trim($line))) { // Only display non-empty lines
        echo "<li>" . htmlspecialchars($line) . "</li>";
    }
}

echo "</ul>";
echo "</div>";
?>
