<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI IN SHAPE</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link href="css/style.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bot.css">
</head>
<body>
    <?php include 'headerUser.php'; ?>

    <div class="chat-container">
        <div class="chat-history" id="history-container">
            <h2>Discussion</h2>
            <ul id="history">
                <!-- Chat messages will be displayed here -->
            </ul>
        </div>
        <div class="chat-box">
            <form id="chat-form">
                <input type="text" id="chat-input" placeholder="Type your message..." autocomplete="off">
                <button type="submit">Send</button>
            </form>
        </div>
    </div>

    <script>
        const chatForm = document.getElementById('chat-form');
        const chatInput = document.getElementById('chat-input');
        const history = document.getElementById('history');
        const historyContainer = document.getElementById('history-container');

        // Function to add a message to the chat history
        const addMessageToHistory = (sender, message) => {
            const messageElement = document.createElement("li");
            messageElement.textContent = `${sender}: ${message}`;
            history.appendChild(messageElement);

            // Auto-scroll to the bottom
            historyContainer.scrollTop = historyContainer.scrollHeight;
        };

        // Handle chat form submission
        chatForm.addEventListener("submit", async (e) => {
            e.preventDefault(); // Prevent form from reloading the page

            const userMessage = chatInput.value.trim();
            if (!userMessage) return;

            // Add user's message to the chat history
            addMessageToHistory("You", userMessage);

            // Send the user's message to the server
            try {
                const response = await fetch("chatbotHandler.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ user_message: userMessage }),
                });
                const result = await response.json();

                if (result.status === "success") {
                    // Add the bot's response to the chat history
                    addMessageToHistory("Bot", result.bot_response);
                } else {
                    addMessageToHistory("Bot", "Error: " + result.message);
                }
            } catch (error) {
                console.error("Failed to communicate with the server:", error);
                addMessageToHistory("Bot", "An error occurred. Please try again.");
            }

            // Clear the input field
            chatInput.value = "";
        });
    </script>
</body>
</html>
