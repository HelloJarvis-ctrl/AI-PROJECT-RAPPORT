<?php
require 'vendor/autoload.php'; // Include Composer autoload if using the MongoDB library

try {
    // Replace <username>, <password>, <cluster-url>, and <dbname> with your details
    $client = new MongoDB\Client("mongodb+srv://molbafana0103:Optahz123@cluster0.v70wf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");

    // Select a database
    $db = $client->selectDatabase('AI');

    // Test: List collections in the database
    $collections = $db->listCollections();
    foreach ($collections as $collection) {
        echo "Collection: " . $collection->getName() . "<br>";
    }

    echo "Connection to MongoDB Atlas was successful!";
} catch (Exception $e) {
    echo "Error connecting to MongoDB: " . $e->getMessage();
}
?>
