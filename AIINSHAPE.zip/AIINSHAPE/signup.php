<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI IN SHAPE</title>
    <!-- slider stylesheet -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!-- bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <!-- fonts style -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" />
    <!-- responsive style -->
    <link href="css/responsive.css" rel="stylesheet" />
    <link href="css/signup.css" rel="stylesheet" />
</head>
<body>
<div class="hero_areaa">
    <?php
        // Include the header.php file
        include 'header.php';
    ?>
     
    <div class="chihaja" >
        <form action="signupProcess.php" method="POST" class="signup-form">
            <div class="ldakhel">
               <div class="1">
                <h2 class="signup-title">SIGN UP</h2>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
                </div>

                <div class="form-group">
                    <label for="height">Height (cm)</label>
                    <input type="number" id="height" name="height" class="form-control" placeholder="Enter your height" required>
                </div>

                <div class="form-group">
                    <label for="weight">Weight (kg)</label>
                    <input type="number" id="weight" name="weight" class="form-control" placeholder="Enter your weight" required>
                </div>
                </div>
                <div class="2">
                <div class="form-group">
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" class="form-control" placeholder="Enter your age" required>
                </div>

                <div class="form-group">
                    <label for="fitness_goal">Fitness Goal</label>
                    <select id="fitness_goal" name="fitness_goal" class="form-control" required>
                        <option value="">Select your goal</option>
                        <option value="weight_loss">Weight Loss</option>
                        <option value="muscle_gain">Muscle Gain</option>
                        <option value="endurance">Endurance</option>
                        <option value="general_fitness">General Fitness</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="experience_level">Experience Level</label>
                    <select id="experience_level" name="experience_level" class="form-control" required>
                        <option value="">Select your experience level</option>
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>
                
                <button type="submit" class="botona">Sign Up</button>
                <p class="signin-link">Already have an account? <a href="signin.php">Sign In</a></p>
                </div>
            </div>
        </form>
    </div>
</div>

</body>
</html>
