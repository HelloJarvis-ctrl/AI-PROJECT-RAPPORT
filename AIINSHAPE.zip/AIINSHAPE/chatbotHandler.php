<?php
header('Content-Type: application/json');
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

$userId = $_SESSION['user_id']; // ID utilisateur provenant de la session

// Capturer les données d'entrée depuis le frontend (POST)
$data = json_decode(file_get_contents('php://input'), true);
$userMessage = trim($data['user_message'] ?? '');

// Vérification du message utilisateur
if (empty($userMessage)) {
    echo json_encode(['status' => 'error', 'message' => 'No user message provided.']);
    exit;
}

// URL de l'API (remplacez avec votre URL Ngrok valide)
$api_url = "https://27db-34-168-137-99.ngrok-free.app/recommend";

// Préparer les données à envoyer à l'API externe
$requestData = [
    "query" => $userMessage,
    "api_key" => ""
];

// Configurer cURL
$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);

// Gérer les erreurs cURL
if (curl_errno($ch)) {
    echo json_encode(['status' => 'error', 'message' => 'cURL Error: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

// Décoder la réponse de l'API
$responseData = json_decode($response, true);
$botResponse = $responseData['response'] ?? "No response received from the API.";

// Enregistrer l'historique du chat dans MongoDB
$chatHistory = [
    'user_message' => $userMessage,
    'bot_response' => $botResponse,
    
];

try {
    // Connexion à MongoDB
    $mongo = new MongoDB\Driver\Manager("mongodb+srv://@cluster0.v70wf.mongodb.net/?retryWrites=true&w=majority");//REPLACE HERE TOO

    // Ajouter l'historique de chat dans la collection
    $bulk = new MongoDB\Driver\BulkWrite;
    $bulk->update(
        ['_id' => new MongoDB\BSON\ObjectId($userId)], // Filtre basé sur l'ID utilisateur
        ['$push' => ['chat_history' => $chatHistory]], // Ajouter à l'historique
        ['upsert' => true] // Insérer si le document utilisateur n'existe pas
    );

    $result = $mongo->executeBulkWrite('AI.USER', $bulk);

    echo json_encode([
        'status' => 'success',
        'bot_response' => $botResponse
    ]);
} catch (MongoDB\Driver\Exception\Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to save to MongoDB: ' . $e->getMessage()]);
}
?>
