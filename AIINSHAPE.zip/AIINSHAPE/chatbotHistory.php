<?php
require 'vendor/autoload.php'; // Include MongoDB library via Composer
session_start();

use MongoDB\Client;
use MongoDB\BSON\ObjectId;

header('Content-Type: application/json');

// MongoDB connection
try {
    $mongoClient = new Client("mongodb+srv://molbafana0103:Optahz123@cluster0.v70wf.mongodb.net/?retryWrites=true&w=majority");
    $database = $mongoClient->selectDatabase('AI');
    $userCollection = $database->selectCollection('USER');
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to connect to MongoDB: ' . $e->getMessage()]);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['USER_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

// Ensure the user ID is valid
try {
    $userId = new ObjectId($_SESSION['user_id']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid user ID.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    // Validate the input
    if (!isset($input['user_message']) || empty($input['user_message'])) {
        echo json_encode(['status' => 'error', 'message' => 'User message is required.']);
        exit;
    }

    $userMessage = trim($input['user_message']);
    $botResponse = "You said: \"$userMessage\". How can I help you further?";

    // Prepare the chat data
    $chatData = [
        'user_message' => $userMessage,
        'bot_response' => $botResponse,
        'timestamp' => new MongoDB\BSON\UTCDateTime((new DateTime())->getTimestamp() * 1000), // MongoDB compatible timestamp
    ];

    // Update the user's chat history
    try {
        $updateResult = $userCollection->updateOne(
            ['_id' => $userId], // Find the user by ID
            ['$push' => ['chat_history' => $chatData]] // Append the chat data to the chat_history array
        );

        if ($updateResult->getModifiedCount() === 1) {
            echo json_encode([
                'status' => 'success',
                'bot_response' => $botResponse,
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update chat history.']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update chat history: ' . $e->getMessage()]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch the user's chat history
    try {
        $user = $userCollection->findOne(['_id' => $userId], ['projection' => ['chat_history' => 1]]);

        if ($user && isset($user['chat_history'])) {
            echo json_encode([
                'status' => 'success',
                'chat_history' => $user['chat_history'],
            ]);
        } else {
            echo json_encode(['status' => 'success', 'chat_history' => []]); // Return empty history if none exists
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to fetch chat history: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
