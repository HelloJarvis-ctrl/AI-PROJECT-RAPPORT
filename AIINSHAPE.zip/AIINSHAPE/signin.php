<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI IN SHAPE - Sign In</title>

    <!-- Owl Carousel stylesheet -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" />
    <link href="css/siginBOX.css" rel="stylesheet" />
    
    <!-- Responsive style -->
    <link href="css/responsive.css" rel="stylesheet" />
</head>
<body>
<div class="hero_area">
    <?php
        // Inclure le fichier header.php
        include 'header.php';  // ou require 'header.php';
    ?>

    <!-- Sign-In Form Container -->
    <div class="signinBOX" name="signin-box">
        <form action="siginProcess.php" method="POST" class="signin-form">
            <div class="ldakhel">
                <h2 class="signin-title">SIGN IN</h2>
                
                <!-- Email Input -->
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
                
                <!-- Password Input -->
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                
                <!-- Sign-In Button -->
                <button type="submit" class="btn btn-primary signin-btn">Sign In</button>
                
                <!-- Link to Sign-Up -->
                <p class="signup-link">Don't have an account? <a href="signup.php">Sign Up</a></p>
            </div>
        </form>
    </div>
</div>
</body>
</html>
