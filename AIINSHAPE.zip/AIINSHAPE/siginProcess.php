<?php
require 'vendor/autoload.php'; // Charger l'autoloader de Composer pour MongoDB

use MongoDB\Client;

// Connexion à MongoDB
$mongoClient = new Client("mongodb+srv://@cluster0.v70wf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");

// Sélection de la base de données et de la collection
$database = $mongoClient->selectDatabase('AI'); 
$collection = $database->selectCollection('USER');

// Vérification si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $user = $collection->findOne(['email' => $email]);

    if ($user) {
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = (string)$user['_id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];

            // Rediriger vers le chatbot
            header('Location: chatbot.php');
            exit;
        } else {
            echo "<script>alert('Mot de passe incorrect. Veuillez réessayer.'); window.location.href='signin.php';</script>";
        }
    } else {
        echo "<script>alert('Aucun compte trouvé avec cet email.'); window.location.href='signin.php';</script>";
    }
} else {
    header('Location: signin.php');
    exit;
}
?>

?>
