<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

<!-- bootstrap core css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

<!-- fonts style -->
<link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="css/style.css" rel="stylesheet" />
<!-- responsive style -->
<link href="css/responsive.css" rel="stylesheet" />
</head>
<body>
<?php
    // Inclure le fichier header.php
    include 'header.php';  // ou require 'header.php';
    ?>
    <!-- slider section -->
    <section class=" slider_section position-relative">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h1>
                      AI
                    </h1>
                    <h1>
                      IN
                    </h1>
                    <h1>
                      SHAPE
                    </h1>
                    <p>
                      Welcome to Workout App, your personalized fitness companion. Explore tailored workout plans, progress tracking, and an AI-powered assistant to guide you every step of the way!                    </p>
                    <div class="">
                      <a href="letschat.php">
Start CHATTING                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h1>
                      AI
                    </h1>
                    <h1>
                      IN
                    </h1>
                    <h1>
                      SHAPE
                    </h1>
                    <p>
                      Why choose us? Get access to personalized workout routines, a rich exercise database, progress tracking, and an AI chatbot for instant fitness advice – all in one app!                    </p>
                    <div class="">
                      <a href="letschat.php">
Start CHATTING                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h1>
                      AI
                    </h1>
                    <h1>
                      IN
                    </h1>
                    <h1>
                      SHAPE
                    </h1>
                    <p>
                      Meet your virtual fitness coach! Ask our AI-powered chatbot anything – from workout suggestions to exercise tips – and get instant, personalized answers.                    </p>
                    <div class="">
                      <a href="letschat.php">
                        Start CHATTING
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h1>
                      AI
                    </h1>
                    <h1>
                      IN
                    </h1>
                    <h1>
                      SHAPE
                    </h1>
                    <p>
                      Discover over 500 exercises, categorized by muscle group, difficulty, and equipment. From beginner-friendly moves to advanced techniques, we’ve got you covered!                    </p>
                    <div class="">
                      <a href="">
Start CHATTING                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container">
              <div class="col-lg-10 col-md-11 mx-auto">
                <div class="detail-box">
                  <div>
                    <h1>
                      AI
                    </h1>
                    <h1>
                      IN 
                    </h1>
                    <h1>
                      SHAPE
                    </h1>
                    <p>
                      Stay motivated with progress tracking. Log your workouts, monitor your achievements, and crush your fitness goals with ease.                    </p>
                    <div class="">
                      <a href="">
Start CHATTING                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
        </ol>
      </div>
    </section>
    <!-- end slider section -->
  </div>


  <!-- Us section -->

  <section class="us_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Why Choose Us
        </h2>
      </div>

      <div class="us_container ">
        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="box">
              <div class="img-box">
                <img src="images/u-1.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Personalized Fitness Plans                </h5>
                <p>
                  We tailor every workout plan to your unique goals, fitness level, and available equipment. Whether you’re at home or in the gym, we’ve got you covered.
                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="box">
              <div class="img-box">
                <img src="images/u-4.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  AI-Powered Assistance
                </h5>
                <p>
                  Our AI chatbot is your 24/7 fitness coach, providing instant answers to your questions and recommending workouts tailored to your needs.                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="box">
              <div class="img-box">
                <img src="images/u-2.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Comprehensive Exercise Library                </h5>
                <p>
                  Access over 500 exercises with step-by-step instructions, images, and muscle group details, so you can master every move with confidence.                </p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="box">
              <div class="img-box">
                <img src="images/u-3.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Flexible Workouts                </h5>
                <p>
                  Don’t have gym equipment? No problem! Our app provides bodyweight exercises and equipment-based options to suit your preferences.                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end us section -->


  <!-- heathy section -->

  <section class="heathy_section layout_padding">
    <div class="container">

      <div class="row">
        <div class="col-md-12 mx-auto">
          <div class="detail-box">
            <h2>
              HEALTHY MIND, HEALTHY BODY
            </h2>
            <p>
              A healthy mind and a healthy body go hand in hand. When we care for our mental health, we unlock the energy and focus needed to take care of our physical well-being. Regular exercise not only strengthens the body but also boosts mood, reduces stress, and enhances mental clarity. Similarly, mindfulness and self-care empower us to make better choices for our physical health. By nurturing both, we create a balanced, fulfilling lifestyle that promotes long-term happiness and vitality. Prioritize your mind and body—they work together to create the best version of you!            </p>

          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- end heathy section -->

  <!-- trainer section -->

  <section class="trainer_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Our Gym Trainers
        </h2>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-6 mx-auto">
          <div class="box">
            <div class="name">
              <h5>
                Smirth Jon
              </h5>
            </div>
            <div class="img-box">
              <img src="images/blackk.jpg" alt="">
            </div>
            <div class="social_box">
              <a href="">
                <img src="images/facebook-logo.png" alt="">
              </a>
              <a href="">
                <img src="images/twitter.png" alt="">
              </a>
              <a href="">
                <img src="images/instagram-logo.png" alt="">
              </a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mx-auto">
          <div class="box">
            <div class="name">
              <h5>
                Jean Doe
              </h5>
            </div>
            <div class="img-box">
              <img src="images/COACH 2.jpg" alt="">
            </div>
            <div class="social_box">
              <a href="">
                <img src="images/facebook-logo.png" alt="">
              </a>
              <a href="">
                <img src="images/twitter.png" alt="">
              </a>
              <a href="">
                <img src="images/instagram-logo.png" alt="">
              </a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 mx-auto">
          <div class="box">
            <div class="name">
              <h5>
                Alex Den
              </h5>
            </div>
            <div class="img-box">
              <img src="images/black coach.jpg" alt="">
            </div>
            <div class="social_box">
              <a href="">
                <img src="images/facebook-logo.png" alt="">
              </a>
              <a href="">
                <img src="images/twitter.png" alt="">
              </a>
              <a href="">
                <img src="images/instagram-logo.png" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end trainer section -->

  <!-- contact section -->

  <section class="contact_section ">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 px-0">
          <div class="img-box">
            <img src="images/4th.png" alt="">
          </div>
        </div>
        <div class="col-lg-5 col-md-6">
          <div class="form_container pr-0 pr-lg-5 mr-0 mr-lg-2">
            <div class="heading_container">
              <h2>
                <a href="feedback.html">GIVE US FEEDBACK :)</a>
              </h2>
            </div>
            <form action="">
              <div>
                <input type="text" placeholder="Name" />
              </div>
              <div>
                <input type="email" placeholder="Email" />
              </div>
            
              <div>
                <input type="text" class="message-box" placeholder="Message" />
              </div>
              <div class="d-flex ">
                <button>
                  Send
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end contact section -->
  <?php
    // Inclure le fichier header.php
    include 'footer.php';  // ou require 'header.php';
    ?>
</body>
</html>