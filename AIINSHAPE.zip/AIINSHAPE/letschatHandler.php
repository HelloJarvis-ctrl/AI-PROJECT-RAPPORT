<?php
header('Content-Type: application/json');

// Capture input data from frontend (assuming POST)
$data = json_decode(file_get_contents('php://input'), true);
$userMessage = $data['user_message'] ?? null;  // Retrieve the user's message

if (!$userMessage) {
    echo json_encode(['status' => 'error', 'message' => 'No user message provided.']);
    exit;
}

$api_url = "https://27db-34-168-137-99.ngrok-free.app/recommend"; // Replace with your Ngrok URL

// Send the user message to the API
$requestData = array(
    "query" => $userMessage,
    "api_key" => ""
);

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

$response = curl_exec($ch);
curl_close($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo json_encode(['status' => 'error', 'message' => "cURL Error: " . curl_error($ch)]);
    exit;
}

// Decode the API response
$responseData = json_decode($response, true);

// Extract the 'response' key
$botResponse = isset($responseData['response']) ? $responseData['response'] : "No response received.";

echo json_encode([
    'status' => 'success',
    'bot_response' => $botResponse
]);
?>
